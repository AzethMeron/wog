archived on 20.02.2021
might be outdated
always up-to-date version: azethmeron.github.io