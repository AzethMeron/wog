This is archived version of ERM/Lua Help. Covers every feature of Alpha 8.0, and beyond
Made on 17.02.2021 Might be outdated. 
Always up-to-date version - azethmeron.github.io
