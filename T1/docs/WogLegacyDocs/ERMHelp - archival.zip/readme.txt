This is archived version of ERM/Lua Help. Covers every feature of Alpha 8.0
Made on 25.07.2020. Might be outdated. 
Always up-to-date version - azethmeron.github.io
